angular.module('starter.controllers', [])

.controller('DashCtrl', function($scope) {
  
});
